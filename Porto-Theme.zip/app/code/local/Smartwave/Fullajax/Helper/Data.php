<?php

class Smartwave_Fullajax_Helper_Data extends Mage_Core_Helper_Abstract
{
}
