<?php

class Smartwave_Porto_Model_System_Config_Source_Setting_Installation_Demoversion
{
    public function toOptionArray()
    {
        return array(
            array('value' => '0', 'label' => Mage::helper('porto')->__('All')),
            array('value' => 'demo01', 'label' => Mage::helper('porto')->__('Demo 1')),
            array('value' => 'demo02', 'label' => Mage::helper('porto')->__('Demo 2')),
            array('value' => 'demo03', 'label' => Mage::helper('porto')->__('Demo 3')),
            array('value' => 'demo04', 'label' => Mage::helper('porto')->__('Demo 4')),
            array('value' => 'demo05', 'label' => Mage::helper('porto')->__('Demo 5')),
            array('value' => 'demo06', 'label' => Mage::helper('porto')->__('Demo 6')),
            array('value' => 'demo07', 'label' => Mage::helper('porto')->__('Demo 7')),
            array('value' => 'demo08', 'label' => Mage::helper('porto')->__('Demo 8')),
            array('value' => 'demo09', 'label' => Mage::helper('porto')->__('Demo 9')),
            array('value' => 'demo10', 'label' => Mage::helper('porto')->__('Demo 10')),
            array('value' => 'demo11', 'label' => Mage::helper('porto')->__('Demo 11')),
            array('value' => 'demo12', 'label' => Mage::helper('porto')->__('Demo 12')),
            array('value' => 'demo13', 'label' => Mage::helper('porto')->__('Demo 13')),
            array('value' => 'demo14', 'label' => Mage::helper('porto')->__('Demo 14')),
            array('value' => 'demo15', 'label' => Mage::helper('porto')->__('Demo 15')),
            array('value' => 'demo16', 'label' => Mage::helper('porto')->__('Demo 16')),
            array('value' => 'demo17', 'label' => Mage::helper('porto')->__('Demo 17')),
            array('value' => 'demo18', 'label' => Mage::helper('porto')->__('Demo 18')),
            array('value' => 'demo19', 'label' => Mage::helper('porto')->__('Demo 19')),
            array('value' => 'demo20', 'label' => Mage::helper('porto')->__('Demo 20'))
        );
    }
}